def handler(event, context):
    raise RuntimeError('No release deployed yet')
